	<section class="footerRow" >
		<div class="col-md-12 col-sm-12  col-xs-12">
		{{--&copy; 2016 News management--}}
		</div>
	</section>
    </body>
</html>