###Publish News ##########
## Requirements ######################
1. laravel 5.3
2. Bootstrap


## Installation steps ################
1. create project directory and paste this Source folder in it.

2. cd project folder
( Please configure virtual host to run this folder and point it project folder/public/)

3. Run : chmod 0777 -R storage
         chmod 0777 -R bootstrap/cache
         chmod 0777 -R public/uploads/

4. Run Database/db.sql from phpmyadmin or workbench
    - This will create database, require tables and test data
    - Sample data for display and login are under Database/data.sql
    
5. update .env file for database connection, update below variables
        DB_CONNECTION=mysql
        DB_HOST=127.0.0.1
        DB_PORT=3306
        DB_DATABASE=crossover_news
        DB_USERNAME=root
        DB_PASSWORD=

6. To run testcase : run phpunit

7. (optional) Run : composer update


## Documentation ###
1. I have included swf in Wink directory.
2. In Design directory - some specificaton and ER Diagram
3. Not covered all unit test due to time constraint.
