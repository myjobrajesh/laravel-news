--
-- sample data to test
--
-- sample Login credentials: email = myjob.rajesh@gmail.com, password = Test@1234
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `last_login`, `email_verify`, `status`, `created_at`, `updated_at`) VALUES
(1, 'rajesh chaudhari', 'myjob.rajesh@gmail.com', '$2y$10$bt4OhSzTMQZrD4r/DgHK0emYhXCkSI4pVbdS5qdFbvVMa2E/t30te', NULL, '2016-11-04 08:45:34', 1, 'active', '2016-11-04 08:42:20', NULL);

INSERT INTO `news` (`id`, `title`, `slug`, `description`, `filepath`, `user_id`, `status`, `created_at`) VALUES
(1, 'news for testing application on laravel platform', 'news-for-testing-application-on-laravel-platform', '<p>Good experience over the network. <span class="st">The <em>networks</em> property of the Homestead.yaml configures <em>network</em> interfaces for your Homestead environment. </span><span class="st">A social <em>network</em> app built with <em>Laravel</em></span><br></p>', '/uploads/2016/11/0c662de0446ea4f9a120c6a815a5335eca6025fd.png', 1, 'active', '2016-11-04 08:50:10');



